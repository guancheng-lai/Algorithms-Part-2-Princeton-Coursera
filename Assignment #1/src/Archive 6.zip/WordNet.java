import edu.princeton.cs.algs4.Digraph;
import edu.princeton.cs.algs4.StdOut;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

public class WordNet {

    private final HashMap<Integer, String> vertexIdx2Synset;
    private final HashMap<String, Integer> string2VertId;
    private final SAP sap;

    // constructor takes the name of the two input files
    public WordNet(String synsets, String hypernyms) {
        if (synsets == null || hypernyms == null) {
            throw new IllegalArgumentException();
        }
        vertexIdx2Synset = new HashMap<>();
        string2VertId = new HashMap<>();
        try (Scanner scanner = new Scanner(new File(synsets))) {
            while (scanner.hasNextLine()) {
                String[] synset = scanner.nextLine().split(",");
                int v = Integer.parseInt(synset[0]);
                String[] synonyms = synset[1].split(" ");
                vertexIdx2Synset.put(v, synset[1]);
                for (String synonym : synonyms) {
                    string2VertId.put(synonym, v);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        Digraph digraph = new Digraph(getNumberOfLines(hypernyms));
        try (Scanner scanner = new Scanner(new File(hypernyms))) {
            while (scanner.hasNextLine()) {
                String[] hypernym = scanner.nextLine().split(",");
                int currentNode = Integer.parseInt(hypernym[0]);
                for (int i = 1; i < hypernym.length; ++i) {
                    digraph.addEdge(currentNode, Integer.parseInt(hypernym[i]));
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        sap = new SAP(digraph);
    }

    private int getNumberOfLines(String fileName) {
        int lines = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            while (reader.readLine() != null) {
                lines++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

    // returns all WordNet nouns
    public Iterable<String> nouns() {
        return string2VertId.keySet();
    }

    // is the word a WordNet noun?
    public boolean isNoun(String word) {
        if (word == null) {
            throw new IllegalArgumentException();
        }
        return string2VertId.containsKey(word);
    }

    // distance between nounA and nounB (defined below)
    public int distance(String nounA, String nounB) {
        if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException();
        }
        return sap.length(string2VertId.get(nounA), string2VertId.get(nounB));
    }

    // a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
    // in a shortest ancestral path (defined below)
    public String sap(String nounA, String nounB) {
        if (nounA == null || nounB == null || !isNoun(nounA) || !isNoun(nounB)) {
            throw new IllegalArgumentException();
        }
        int ancestor = sap.ancestor(string2VertId.get(nounA), string2VertId.get(nounB));
        return vertexIdx2Synset.get(ancestor);
    }

    // do unit testing of this class
    public static void main(String[] args) {
        StdOut.println("INPUT: " + args[0] + " " + args[1]);
        WordNet wordNet = new WordNet(args[0], args[1]);
        StdOut.println(wordNet.sap("Montmartre", "Forbidden_City"));
        if (wordNet.isNoun("anamorphosis")) {
            StdOut.println("anamorphosis");
        }
    }
}